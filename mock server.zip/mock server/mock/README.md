PetStore Mock Server
--------------------------
This web-based documentation demonstrates the most simplistic usage of Swagger UI and Codegen. 
It simply creates a new web Application and adds all of the Swagger components without changing any options, 
and without adding any custom middleware such as setting a few options, 
initializing the mock data store, and adding custom middleware logic.



